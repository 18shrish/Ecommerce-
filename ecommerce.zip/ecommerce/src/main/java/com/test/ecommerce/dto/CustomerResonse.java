package com.test.ecommerce.dto;

public class CustomerResonse {


	    private Integer customerId;
	    private String firstName;
	    private String lastName;

	    public Integer getCustomerId() {
	        return customerId;
	    }
	    public void setCustomerId(Integer customerId) {
	        this.customerId = customerId;
	    }
	    public String getFirstName() {
	        return firstName;
	    }
	    public void setFirstName(String firstName) {
	        this.firstName = firstName;
	    }
	    public String getLastName() {
	        return lastName;
	    }
	    public void setLastName(String lastName) {
	        this.lastName = lastName;
	    }
	}

